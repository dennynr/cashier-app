<?php
    $currentRouteName = Route::currentRouteName();
?>

<nav id="sidebar" class="col-md-1">
    <div class="position-sticky">
        <!-- Sidebar Logo -->
        <div class="text-center my-4 mb-5">
            <img src="<?php echo e(asset('images/logo.png')); ?>" id="sidebar-logo" alt="Logo" width="100" class="rounded">
        </div>
        <!-- Sidebar Items -->
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="bi bi-egg-fried"></i>
                    <span>Menu</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('items.index')); ?>">
                    <i class="bi bi-box"></i>
                    <span>Item</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('profit')); ?>">
                    <i class="bi bi-cash-coin"></i>
                    <span>Profit</span>
                </a>
            </li>
            <li class="nav-item mb-5">
                <a class="nav-link" href="<?php echo e(route('transaksi')); ?>">
                    <i class="bi bi-clock-history"></i>
                    <span>Transaksi</span>
                </a>
            </li>
            <li class="nav-item mt-5">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="bi bi-box-arrow-left"></i>
                    <span>Logout</span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li> 
        </ul>
    </div>
</nav>
<?php /**PATH D:\Project UAS\uas\resources\views/layouts/nav.blade.php ENDPATH**/ ?>