<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <main class="col-md-11 bg-light p-4" style="width:91%">
        <!-- Card Kasir -->
        <div class="card kasir-card">
            <div class="card-body">
                <span class="card-title">Hi Im Cashier</span><br>
                <span class="card-subtitle">
                    <?php if(session('username')): ?>
                        <?php echo e(session('username')); ?>

                    <?php else: ?>
                        Guest User
                        <!-- Or any default value you want to show when no username is stored in the session -->
                    <?php endif; ?>
                </span>
            </div>
        </div>
        <!-- Tabel Item -->
        <div class="mt-4 text-end me-3">
            <button class="btn btn-add" id="addItemBtn" data-bs-toggle="modal" data-bs-target="#addItemModal">
                <i class="bi bi-plus"></i> Add Item </button>
        </div>
        <h3 class="title-item mb-3">Items</h3>
        <div class="table-responsive p-4 rounded-4" style="width:100%;">
            <table id="example" class="table table-striped" style="width:100% ">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Items</th>
                        <th>Harga</th>
                        <th>Jenis</th>
                        <th>Stock</th>
                        <th>Option</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($post->code_item); ?></td>
                            <td><?php echo e($post->name_item); ?></td>
                            <td>Rp <?php echo e($post->price); ?></td>
                            <td><?php echo e($post->type->type); ?></td>
                            <td><?php echo e($post->qty); ?></td>
                            <td>
                                <?php echo $__env->make('items.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- Tambahkan baris lain untuk item lainnya -->
                </tbody>
            </table>
        </div>
        <!-- Modal Add Item -->
        <div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addItemModalLabel"><?php echo e($CreateItem); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Form Add Item -->
                        <form action="<?php echo e(route('items.store')); ?>" id="addItemForm" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="itemName" class="form-label">Item Name</label>
                                <input type="text" class="form-control" name="itemName" id="itemName"
                                    value="<?php echo e(old('itemName')); ?>" placeholder="Nama barang, Contoh: Indomie" required>
                            </div>
                            <div class="mb-3">
                                <label for="itemWholesalePrice" class="form-label">Harga Beli</label>
                                <input type="number" class="form-control" name="itemBuy" id="itemWholesalePrice"
                                    placeholder="Harga barang asli barang ketika kulak"
                                    value="<?php echo e(old('itemWholesalePrice')); ?>" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="itemPrice" class="form-label">Item Price (Rp)</label>
                                    <input type="number" class="form-control" name="itemPrice" id="itemPrice"
                                        value="<?php echo e(old('itemPrice')); ?>" placeholder="Harga yang akan dijual" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="itemStock" class="form-label">Item Stock</label>
                                    <input type="number" class="form-control" name="itemStock" id="itemStock"
                                        value="<?php echo e(old('itemStock')); ?>" min="1"
                                        placeholder="Isi dari box/renteng contoh: 12" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="itemType" class="form-label">Jenis</label>
                                <select class="form-select form-control" name="itemType" id="itemType" required>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"
                                            <?php echo e(old('itemType') == $type->id ? 'selected' : ''); ?>>
                                            <?php echo e($type->type); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="itemImage" class="form-label">Item Image</label>
                                <input type="file" class="form-control" name="itemImage" id="itemImage" accept="image/*"
                                    required>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-success" id="saveItemBtn">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Modal -->
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="editModal_<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Edit Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <form id="editItemForm_<?php echo e($item->id); ?>"
                            action="<?php echo e(route('items.update', ['item' => $item->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-body">
                                <!-- Form untuk mengedit item -->
                                <div class="mb-3">
                                    <label for="editItemName_<?php echo e($item->id); ?>" class="form-label">Nama
                                        Item</label>
                                    <input type="text" class="form-control" id="editItemName_<?php echo e($item->id); ?>"
                                        value="<?php echo e($item->name_item); ?>" name="itemName" required>
                                </div>
                                <div class="mb-3">
                                    <label for="editItemPrice_<?php echo e($item->id); ?>" class="form-label">Harga Item
                                        (Rp)
                                    </label>
                                    <input type="number" class="form-control" value="<?php echo e($item->price); ?>"
                                        id="editItemPrice_<?php echo e($item->id); ?>" name="itemPrice" min="0" required>
                                </div>
                                <!-- Tambahkan kolom lain yang ingin diubah -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Add Stock Modal -->
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- ... code sebelumnya ... -->
            <!-- Modal for adding stock -->
            <div class="modal fade" id="addStockModal_<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="addStockModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addStockModalLabel">Add Stock</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <form action="<?php echo e(route('items.addStock', ['item' => $item->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <!-- Add your form fields here for adding stock -->
                                <div class="mb-3">
                                    <label for="addStockAmount" class="form-label">Stock Amount</label>
                                    <input type="number" class="form-control" id="addStockAmount_<?php echo e($item->id); ?>"
                                        name="stockAmount" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </main>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        // Pastikan ini dijalankan setelah sumber daya Bootstrap dimuat
        $(document).ready(function() {
            var myModal = new bootstrap.Modal(document.getElementById('addItemModal'));
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        new DataTable('#example');
        // resources/js/app.js atau file JavaScript terpisah yang Anda gunakan

        // Fungsi untuk menampilkan SweetAlert konfirmasi delete
    </script>
    <script>
        // Add event listener to delete buttons
        const deleteButtons = document.querySelectorAll('.delete-button');
        deleteButtons.forEach((button) => {
            button.addEventListener('click', function(event) {
                event.preventDefault();

                const name = this.getAttribute('data-name');
                const form = document.getElementById('deleteForm' + this.getAttribute('data-id'));

                Swal.fire({
                    title: "Are you sure want to delete " + name + "?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: "Yes, delete it!",
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Submit the form when the user confirms the deletion
                        form.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project UAS\uas\resources\views/items/index.blade.php ENDPATH**/ ?>