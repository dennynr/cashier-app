<div class="d-flex" role="group" aria-label="Item Actions">
    <!-- Tombol Edit -->
    <button class="btn btn-primary btn-sm
    me-2" data-item-id="<?php echo e($post->id); ?>" data-bs-toggle="modal"
        data-bs-target="#editModal_<?php echo e($post->id); ?>"><i class="bi bi-pencil-square"></i></button>

    <!-- Tombol Add Stock -->
    <button class="btn btn-success btn-sm me-2"
        data-item-id="<?php echo e($post->id); ?>" data-bs-toggle="modal" data-bs-target="#addStockModal_<?php echo e($post->id); ?>"><i
            class="bi bi-plus-square"></i></button>

    <!-- Form Delete -->
    <form id="deleteForm<?php echo e($post->id); ?>" action="<?php echo e(route('items.destroy', $post->id)); ?>" method="post"
        class="flex-fill">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button type="submit" class="btn
        btn-danger btn-sm me-2 delete-button"
            data-name="<?php echo e($post->code_item . ' ' . $post->name_item); ?>" data-id="<?php echo e($post->id); ?>">
            <i class="bi bi-trash2"></i>
        </button>
    </form>
</div>
<?php /**PATH D:\Project UAS\uas\resources\views/items/actions.blade.php ENDPATH**/ ?>