<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>transaction List</title>
   <style>
       html {
           font-size: 12px;
       }

       .table {
           border-collapse: collapse !important;
           width: 100%;
       }

       .table-bordered th,
       .table-bordered td {
           padding: 0.5rem;
           border: 1px solid black !important;
       }
   </style>
</head>
<body>
   <h1>transaction List</h1>
   <table class="table table-bordered">
       <thead>
           <tr>
               <th>No.</th>
               <th>transaction_code</th>
               <th>items</th>
               <th>prices</th>
               <th>method</th>
               <th>date</th>
           </tr>
       </thead>
       <tbody>
           <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                   <td align="center"><?php echo e($index + 1); ?></td>
                   <td><?php echo e($transaction->transaction_code); ?></td>
                   <td><?php echo e($transaction->items); ?></td>
                   <td><?php echo e($transaction->prices); ?></td>
                   <td align="center"><?php echo e($transaction->method); ?></td>
                   <td><?php echo e($transaction->date); ?></td>
               </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
   </table>
</body>
</html>
<?php /**PATH D:\Project UAS\uas\resources\views/exportPdf.blade.php ENDPATH**/ ?>